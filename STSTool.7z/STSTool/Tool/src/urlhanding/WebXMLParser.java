package urlhanding;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
public class WebXMLParser {
	public static void convertWebXML() throws IOException {
		String buffer = "";
		int i;
		int tab_count=0;
		char ch;
		byte b[];
		
		FileInputStream fin = new FileInputStream("C:\\Users\\Admin\\Desktop\\struts_try\\WebContent\\WEB-INF/web.xml");
		FileOutputStream fout = new FileOutputStream("C:\\Users\\Admin\\Desktop\\Project\\Spring\\WebContent\\WEB-INF/web.xml");
		while((i = fin.read()) != -1) {
			ch = (char)i;
			
			//check for delimiters 
			if((ch == ' ') || (ch == '\n') || (ch == '>')) {
				
				if(ch == '>') {
					buffer += ch;
				}
				
				//check for <struts-class>
				if(buffer.equals("<servlet-class>")) {
					//replace it with spring correspondent
					replace_struts_class(fin,fout,buffer,tab_count);
					buffer = "";
				}
				
				
				//check for <init-param>
				else if(buffer.equals("<init-param>")) {
					//ignore till its closing tag i.e </init-param>
					ignore(fin,"</init-param>");
					buffer = "";
				}
				
				else {
					//displaying line by line
					if(ch == '\n'){	
						indent_tab(tab_count,fout);
						tab_count = 0;
						buffer += "\n";
						b = buffer.getBytes();
						fout.write(b);
						System.out.println(buffer);
						buffer = "";	
					}							
				}
				
			}
			else if(ch == '\t') {
				tab_count++;
			}
			else {
				buffer += ch;
			}
		}
		fin.close();
		fout.close();
	}
	
	static void replace_struts_class(FileInputStream fin,FileOutputStream fout,String buffer,int tab_count) throws IOException {
		byte b[];
		
		//writes <servlet-class> with indentation in spring's file
		indent_tab(tab_count,fout);
		buffer += "\n";
		b = buffer.getBytes();
		fout.write(b);
		
		//writes dispatcher servlet's class with indentation in spring's file
		indent_tab(tab_count+1,fout);
		buffer = "org.springframework.web.servlet.DispatcherServlet";
		buffer += "\n";
		b = buffer.getBytes();
		fout.write(b);
		
		//writes </servlet-class> with indentation in spring's file
		indent_tab(tab_count,fout);
		buffer = "</servlet-class>";
		buffer += "\n";
		b = buffer.getBytes();
		fout.write(b);
		
		//ingoring the lines till </servlet-class> in the struts file 
		ignore(fin,"</servlet-class>");
		
		
	}
	
	static void ignore(FileInputStream fin,String ignore_until) throws IOException {
		char ch;
		int i;
		String buffer = "";
	
		while((i = fin.read()) != -1) {
			ch = (char)i;
							//checking for delimiters
			if((ch == ' ') || (ch == '\n') || (ch == '>')||(ch == '<')) {
				
				if(ch == '>') {
					buffer += ch;
				}				
							//check for the string until which you want to ignore
				if(buffer.equals(ignore_until)) {
					buffer = "";
					break;
				}
				else if((ch == ' ')||(ch == '\n')){
					buffer = "";	//clearing the buffer after every word
				}
				else if(ch == '<'){
					buffer = "";	//clearing and storing the next word in buffer
					buffer += ch;
				}
			}			
			else {			//adding each character to the buffer
				if(ch != '\t'){
					buffer += ch;	//ignoring tabs
				}
			}
			
		}
	}
	
	static void indent_tab(int tab_count,FileOutputStream fout) throws IOException {
		byte b[];
		String buf = "\t";
		
		while(tab_count != 0) {
			System.out.print("\t");
			b = buf.getBytes();
			fout.write(b);
			tab_count--;
		}		
	}
	


}
