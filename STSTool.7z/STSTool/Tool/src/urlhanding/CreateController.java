package urlhanding;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Set;

public class CreateController
{
	public static Hashtable<String,String> h = new Hashtable<String,String>();
	public static Hashtable<String,String> h1 = new Hashtable<String,String>();
	public static Hashtable<String,String> h2 = new Hashtable<String,String>();
	
	public static void addheader(FileWriter fstream1,BufferedWriter out1) throws IOException {
 
		File fin = new File("headerfiles.txt");
		FileInputStream fis = new FileInputStream(fin);
		BufferedReader in = new BufferedReader(new InputStreamReader(fis));
		String aLine = null;
		while ((aLine = in.readLine()) != null) {
			out1.write(aLine);
			out1.newLine();
		}
		in.close();
	}
	
	public static String searchInTable(Hashtable<String,String> h1,String searchKey)
	{
		Set<String> keys = h1.keySet();
        Iterator<String> iterator = keys.iterator();
        while(iterator.hasNext())
        {
        	String key= iterator.next();
        	if(key.equals(searchKey))
        		return h1.get(key);
        }
        return "NULL";
	}
	
	public static void addControllerMethod(FileWriter fstream1,BufferedWriter out1,String oldString, String newString,String oldString1, String newString1,Hashtable<String,String> h1,Hashtable<String,String> h2) throws IOException {
		 
		File fin1 = new File("controllerMethodTemplate.txt");
		FileInputStream fis1 = new FileInputStream(fin1);
		BufferedReader in1 = new BufferedReader(new InputStreamReader(fis1));
		
		String formName;
		String className;
		
		formName = searchInTable(h2,newString1);
		className =searchInTable(h1,formName);
		System.out.println(className+"  "+formName);
		String aLine = null;
		while ((aLine = in1.readLine()) != null) {
			aLine = aLine.replaceAll(oldString, newString);
			aLine = aLine.replaceAll(oldString1, newString1);
			aLine = aLine.replaceAll("classNameString",className);
			out1.write(aLine);
			out1.newLine();
		}
		in1.close();
	}
	public static void addDispatcherServelet(FileWriter fstream1,BufferedWriter out1) throws IOException {
		 
		File fin = new File("dispatcherTemplate.txt");
		FileInputStream fis = new FileInputStream(fin);
		BufferedReader in = new BufferedReader(new InputStreamReader(fis));
		String aLine = null;
		while ((aLine = in.readLine()) != null) {
			out1.write(aLine);
			out1.newLine();
		}
		in.close();
	}	
	
	public static void Controller() throws IOException
	{
		FileWriter fstream1 = new FileWriter("C:\\Users\\Admin\\Desktop/Project/Spring/src/com/project/controller/controller.java", true);
		BufferedWriter out1 = new BufferedWriter(fstream1);
		addheader(fstream1,out1);
	
		/* Hashtable to create the action class and url mappinfg*/
		h = xmlparser.getMappings();
		h2 = xmlparser.getFormHelpMappings();
		h1 = xmlparser.getFormMappings();
		
		Set<String> keys = h.keySet();
        Iterator<String> iterator = keys.iterator();
        
        while(iterator.hasNext())
        {
        	String key= iterator.next();
        	addControllerMethod(fstream1,out1,"ClassName",h.get(key),"/dummy",key,h1,h2);
        }
        
		out1.newLine();
		out1.write("}");
		out1.close();
	}
	public static void main(String args[]) throws Exception
	{
		ToolClass.SwitchCase(args[0]);
	}
}