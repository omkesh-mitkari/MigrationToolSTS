package urlhanding;
import java.io.File;
public class FileStructure {
    public static void createDirectoryStructure(){
        File project = new File("C:\\Users\\Admin\\Desktop/Project/Spring");
        if(!project.exists())
        {
            project.mkdirs();
        }
        
        File src = new File("C:\\Users\\Admin\\Desktop/Project/Spring/src");
        if(!src.exists())
        {
            src.mkdirs();
        }
        File controller = new File("C:\\Users\\Admin\\Desktop/Project/Spring/src/com/project/controller");
        if(!controller.exists())
        {
            controller.mkdirs();
        }
        File actionClass = new File("C:\\Users\\Admin\\Desktop/Project/Spring/src/com/project/CustomActionClasses");
        if(!actionClass.exists())
        {
            actionClass.mkdirs();
        }
        File SupportFiles = new File("C:\\Users\\Admin\\Desktop/Project/Spring/src/com/project/SupportFiles");
        if(!SupportFiles.exists())
        {
            SupportFiles.mkdirs();
        }
        File webcontent = new File("C:\\Users\\Admin\\Desktop/Project/Spring/WebContent");
        if(!webcontent.exists())
        {          
            webcontent.mkdirs();
        }
        File web_inf = new File("C:\\Users\\Admin\\Desktop/Project/Spring/WebContent/WEB-INF");
        if(!web_inf.exists())
        {          
            web_inf.mkdirs();
        }
        File lib = new File("C:\\Users\\Admin\\Desktop/Project/Spring/WebContent/WEB-INF/lib");
        if(!lib.exists())
        {          
            lib.mkdirs();
        }
        
        File meta_inf = new File("C:\\Users\\Admin\\Desktop/Project/Spring/WebContent/META-INF");
       if(!meta_inf.exists())
        {          
            meta_inf.mkdirs();
        }
    } 
}